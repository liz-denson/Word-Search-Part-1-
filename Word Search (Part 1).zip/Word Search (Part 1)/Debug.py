###############################################################################
# Word Search (DEBUG global)
#
# This makes it easier to enable or disable debug mode across all files.
###############################################################################

# debug mode?
DEBUG = False

